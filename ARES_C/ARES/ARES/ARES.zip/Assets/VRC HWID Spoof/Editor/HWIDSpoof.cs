﻿#if UNITY_EDITOR && (VRC_SDK_VRCSDK3 || VRC_SDK_VRCSDK2)
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using Mono.Cecil;
using Random = System.Random;

using MethodReference = Mono.Cecil.MethodReference;
using OpCodes = Mono.Cecil.Cil.OpCodes;

public class HWIDSpoof : EditorWindow
{
    private bool DeviceIDFoldout = false;
    private bool SpoofDeviceIDFoldout = false;
    private const int char0 = (int)'0';
    private const int char9 = (int)'9';
    private const int chara = (int)'a';
    private const int charz = (int)'z';
    private string customDeviceID = "<custom device id>";

    [MenuItem("VRChat SDK/HWID Spoof Menu", priority = 10000)]
    public static void ShowWindow()
    {
        var w = GetWindow(typeof(HWIDSpoof), false, "VRChat HWID Spoof", true);
        w.minSize = new Vector2(310, 250); w.maxSize = new Vector2(500, 250);
    }

    public void OnGUI()
    {
        DeviceIDFoldout = EditorGUILayout.Foldout(DeviceIDFoldout, "Real Device ID", true);
        if (DeviceIDFoldout)
        {
            EditorGUILayout.SelectableLabel($"  {SystemInfo.deviceUniqueIdentifier}");
        }

        SpoofDeviceIDFoldout = EditorGUILayout.Foldout(SpoofDeviceIDFoldout, "Device ID for VRChat", true);
        if (SpoofDeviceIDFoldout)
        {
            EditorGUILayout.SelectableLabel($"  {VRC.Core.API.DeviceID}");
        }

        if (GUILayout.Button($"Generate New ID", GUILayout.Height(30)))
        {
            GenerateNewDeviceID();
        }

        customDeviceID = EditorGUILayout.TextField(customDeviceID);
        if (GUILayout.Button($"Set Device ID Manually", GUILayout.Height(30)))
        {
            if (!String.IsNullOrWhiteSpace(customDeviceID))
            {
                if (customDeviceID.Length == 40)
                {
                    if (customDeviceID.All(Char.IsLetterOrDigit))
                    {
                        customDeviceID = customDeviceID.ToLower();
                        PlayerPrefs.SetString("SystemInfo_deviceUniqueIdentifier_Spoof", customDeviceID);
                    }
                    else
                    {
                        ShowNotification(new GUIContent("Device ID must be\nalphanumeric characters only."),3);
                    }
                }
                else
                {
                    ShowNotification(new GUIContent("Device ID must be 40 characters long."),3);
                }
            }
        }

        if (GUILayout.Button($"Reset Device ID", GUILayout.Height(30)))
        {
            ResetDeviceID();
        }
    }

    private void GenerateNewDeviceID()
    {
        string deviceID = PlayerPrefs.GetString("SystemInfo_deviceUniqueIdentifier_Spoof", SystemInfo.deviceUniqueIdentifier);
        char[] deviceIDArray = deviceID.ToCharArray();
        char[] NEWdeviceIDArray = new char[deviceIDArray.Length];
        int index = 0;
        var rand = new Random();
        foreach (int i in UniqueRandom(deviceIDArray.Length))
        {
            int charint = (int)deviceIDArray[i];

            int n = rand.Next(0, 6);
            if (n == 0)
            {
                if ((charint >= chara && charint < charz) || (charint < char9 && charint >= char0))
                {
                    charint++;
                }
                else if (charint == char9)
                {
                    charint = chara;
                }
                else if (charint == charz)
                {
                    charint = char0;
                }
            }

            NEWdeviceIDArray[index] = (char)charint;
            index++;
        }
        string NEWdeviceID = new string(NEWdeviceIDArray);
        PlayerPrefs.SetString("SystemInfo_deviceUniqueIdentifier_Spoof", NEWdeviceID);
    }

    private IEnumerable<int> UniqueRandom(int maxExclusive, int minInclusive = 0)
    {
        List<int> candidates = new List<int>();
        for (int i = minInclusive; i < maxExclusive; i++)
        {
            candidates.Add(i);
        }
        Random rnd = new Random();
        while (candidates.Count > 0)
        {
            int index = rnd.Next(candidates.Count);
            yield return candidates[index];
            candidates.RemoveAt(index);
        }
    }

    private void ResetDeviceID()
    {
        PlayerPrefs.DeleteKey("SystemInfo_deviceUniqueIdentifier_Spoof");
    }

    [MenuItem("VRChat SDK/HWID Spoof - Inject", priority = 10000)]
    private static void GetDllsToInject()
    {
        string[] dlls = new string[] { Application.dataPath + "/VRCSDK/Plugins/VRCCore-Editor.dll", Application.dataPath + "/VRCSDK/Plugins/VRCCore-Standalone.dll" };
        bool reloadassemblies = false;
        foreach (string dll in dlls)
        {
            int result = InjectIntoDll(dll);
            if (result == -1)
            {
                Debug.Log("Nothing to patch in " + Path.GetFileName(dll));
            }
            else if (result == 0)
            {
                Debug.Log(Path.GetFileName(dll) + " is already patched!");
            }
            else if (result == 1)
            {
                Debug.Log(Path.GetFileName(dll) + " successfully patched!");
                reloadassemblies = true;
            }
        }
        if (reloadassemblies) CompilationPipeline.RequestScriptCompilation();
    }

    private static int InjectIntoDll(string dll_path)
    {
        int modified = -1;
        if (!File.Exists(dll_path))
        {
            Debug.LogWarning(dll_path + " doesn't exist!");
            return modified;
        }
        string temp_dll_path = dll_path+".temp";
        if (File.Exists(temp_dll_path)) File.Delete(temp_dll_path);
        using (ModuleDefinition module = ModuleDefinition.ReadModule(dll_path))
        {
            MethodReference UnityEngine_PlayerPrefs_GetString = module.ImportReference(typeof(UnityEngine.PlayerPrefs).GetMethod("GetString", new Type[] { typeof(string), typeof(string) }));
            MethodReference UnityEngine_SystemInfo_get_deviceUniqueIdentifier = module.ImportReference(typeof(UnityEngine.SystemInfo).GetMethod("get_deviceUniqueIdentifier"));
            foreach (var type in module.Types)
            {
                foreach (var method in type.Methods)
                {
                    if (!method.HasBody || method.ReturnType.Name != "String")
                    {
                        continue;
                    }
                    foreach (var instr in method.Body.Instructions)
                    {
                        if (instr.OpCode.Name == "ldstr" && instr.Operand.ToString() == "SystemInfo_deviceUniqueIdentifier_Spoof")
                        {
                            modified = Math.Max(modified,0);
                            break;
                        }
                        if (instr.OpCode.Name == "call" && instr.Operand.ToString().Contains("UnityEngine.SystemInfo::get_deviceUniqueIdentifier()"))
                        {
                            method.Body.Variables.Clear();
                            method.Body.Instructions.Clear();
                            var processor = method.Body.GetILProcessor();
                            processor.Emit(OpCodes.Ldstr, "SystemInfo_deviceUniqueIdentifier_Spoof");
                            processor.Emit(OpCodes.Call, UnityEngine_SystemInfo_get_deviceUniqueIdentifier);
                            processor.Emit(OpCodes.Call, UnityEngine_PlayerPrefs_GetString);
                            processor.Emit(OpCodes.Ret);
                            modified = Math.Max(modified, 1);
                            break;
                        }
                    }
                }
            }
            if (modified == 1)
            {
                module.Write(temp_dll_path);
            }
        }
        if (File.Exists(temp_dll_path))
        {
            File.Delete(dll_path); File.Move(temp_dll_path, dll_path);
        }
        return modified;
    }
}
#endif